// SatsDash Bitcoin Wallet - Demo Implementation v4 (bug fix: auth button not working)

class BitcoinWalletDemo {
  constructor() {
    this.currentUser = null;
    this.walletData = null;
    this.btcPrice = 45000;
    this.balance = 0;
    this.transactions = [];

    // DOM is already loaded because we instantiate in DOMContentLoaded
    this.init();
  }

  /* ---------------- Initialisation ---------------- */
  init() {
    if (this.restoreSession()) {
      this.loadWallet();
      this.showDashboard();
    } else {
      this.showLanding();
    }
    this.bindEvents();
    this.renderStaticUI();
  }

  renderStaticUI() {
    document.getElementById('btc-address').textContent = '–';
    document.getElementById('balance-btc').textContent = '0 BTC';
    document.getElementById('balance-usd').textContent = '≈ $0.00';
  }

  /* ---------------- Event Binding ---------------- */
  bindEvents() {
    const $ = id => document.getElementById(id);
    $('google-btn').addEventListener('click', () => this.handleLogin());
    $('logout-btn').addEventListener('click', () => this.logout());
    $('send-btn').addEventListener('click', () => this.showSendModal());
    $('receive-btn').addEventListener('click', () => this.highlightAddress());
    $('close-send').addEventListener('click', () => this.hideSendModal());
    $('modal-overlay').addEventListener('click', () => this.hideSendModal());
    $('confirm-send').addEventListener('click', () => this.processSend());
    $('btc-address').addEventListener('click', () => this.copyAddress());
  }

  /* ---------------- Session Helpers ---------------- */
  saveSession() {
    const session = { user: this.currentUser, expires: Date.now() + 864e5 };
    localStorage.setItem('satsdash_session', JSON.stringify(session));
  }

  restoreSession() {
    try {
      const raw = localStorage.getItem('satsdash_session');
      if (!raw) return false;
      const data = JSON.parse(raw);
      if (data.expires > Date.now()) {
        this.currentUser = data.user;
        return true;
      }
      return false;
    } catch (_) {
      return false;
    }
  }

  /* ---------------- Authentication ---------------- */
  async handleLogin() {
    this.updateStatus('landing-status', 'info', 'Signing in...');
    await this.delay(600);

    // Simulate Google user
    this.currentUser = {
      id: 'uid_' + Math.random().toString(36).substring(2, 8),
      email: 'user@example.com',
      name: 'Demo User'
    };
    this.saveSession();
    await this.setupWallet();
    this.updateStatus('landing-status', 'success', 'Logged in!');
    this.showDashboard();
  }

  /* ---------------- Wallet Management ---------------- */
  async setupWallet() {
    const key = `wallet_${this.currentUser.id}`;
    const existing = localStorage.getItem(key);

    if (existing) {
      this.walletData = JSON.parse(existing);
    } else {
      this.walletData = {
        address: 'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh',
        encrypted: btoa('dummy_mnemonic'),
        created: Date.now()
      };
      localStorage.setItem(key, JSON.stringify(this.walletData));
    }

    this.generateDemoTransactions();
    this.updateBalanceDisplay();
    await this.renderQRCode();
    this.renderTxHistory();
  }

  loadWallet() {
    // Called after restoreSession
    const key = `wallet_${this.currentUser.id}`;
    const data = localStorage.getItem(key);
    if (data) {
      this.walletData = JSON.parse(data);
      this.generateDemoTransactions();
      this.updateBalanceDisplay();
      this.renderTxHistory();
      this.renderQRCode();
    }
  }

  /* ---------------- Landing / Dashboard ---------------- */
  showLanding() {
    document.getElementById('landing').classList.remove('hidden');
    document.getElementById('dashboard').classList.add('hidden');
  }

  showDashboard() {
    document.getElementById('landing').classList.add('hidden');
    document.getElementById('dashboard').classList.remove('hidden');

    document.getElementById('btc-address').textContent = this.walletData.address;
    this.renderQRCode();
    this.updateBalanceDisplay();
    this.renderTxHistory();
  }

  updateStatus(id, type, msg) {
    const el = document.getElementById(id);
    if (!el) return;
    el.className = `status status--${type}`;
    el.textContent = msg;
    el.style.display = 'inline-flex';
  }

  /* ---------------- QR / Clipboard ---------------- */
  async renderQRCode() {
    if (!window.QRCode) return;
    const canvas = document.getElementById('qr-canvas');
    if (!canvas) return;
    try {
      await QRCode.toCanvas(canvas, this.walletData.address, {
        width: 200,
        margin: 1,
        color: { dark: '#13343B', light: '#FFFFFF' }
      });
    } catch (err) {
      console.error('QR code error', err);
    }
  }

  highlightAddress() {
    const el = document.getElementById('btc-address');
    el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    el.style.background = 'var(--color-bg-2)';
    setTimeout(() => (el.style.background = ''), 800);
  }

  async copyAddress() {
    try {
      await navigator.clipboard.writeText(this.walletData.address);
      const el = document.getElementById('btc-address');
      const prev = el.textContent;
      el.textContent = 'Copied!';
      el.style.color = 'var(--color-success)';
      setTimeout(() => {
        el.textContent = prev;
        el.style.color = '';
      }, 1000);
    } catch (_) { /* ignore */ }
  }

  /* ---------------- Transactions ---------------- */
  generateDemoTransactions() {
    if (this.transactions.length) return;
    const now = Date.now();
    this.transactions = [
      { id: this.randomHex(64), amount: 0.0015, conf: 6, time: now - 172800000 },
      { id: this.randomHex(64), amount: -0.0005, conf: 2, time: now - 86400000 },
      { id: this.randomHex(64), amount: 0.00075, conf: 0, time: now - 7200000 }
    ];
  }

  updateBalanceDisplay() {
    const bal = this.transactions.reduce((sum, t) => sum + t.amount, 0);
    this.balance = bal;
    document.getElementById('balance-btc').textContent = `${bal.toFixed(8)} BTC`;
    document.getElementById('balance-usd').textContent = `≈ $${(bal * this.btcPrice).toFixed(2)}`;
  }

  renderTxHistory() {
    const container = document.getElementById('tx-list');
    if (!container) return;
    container.innerHTML = '';
    if (!this.transactions.length) {
      container.innerHTML = '<p class="text-sm">No transactions yet</p>';
      return;
    }

    this.transactions.forEach(tx => {
      const div = document.createElement('div');
      div.className = `tx-item tx-item--${tx.conf ? 'confirmed' : 'pending'}`;
      div.innerHTML = `
        <div class="text-sm">${new Date(tx.time).toLocaleString()} (${tx.conf} conf)</div>
        <span class="${tx.amount>0?'status status--success':'status status--error'}">${tx.amount>0?'+':''}${tx.amount.toFixed(8)} BTC</span>
      `;
      container.appendChild(div);
    });
  }

  /* ---------------- Send Flow ---------------- */
  showSendModal() {
    document.getElementById('modal-overlay').classList.remove('hidden');
    document.getElementById('send-modal').classList.remove('hidden');
  }

  hideSendModal() {
    document.getElementById('modal-overlay').classList.add('hidden');
    document.getElementById('send-modal').classList.add('hidden');
    document.getElementById('recipient').value='';
    document.getElementById('amount').value='';
    document.getElementById('send-status').style.display='none';
  }

  async processSend() {
    const recipient = document.getElementById('recipient').value.trim();
    const amount = parseFloat(document.getElementById('amount').value);
    const status = document.getElementById('send-status');

    const error = msg => {
      status.className = 'status status--error';
      status.textContent = msg;
      status.style.display = 'inline-flex';
    };

    if (!recipient || !amount) return error('Enter address & amount');
    if (amount <= 0 || amount > this.balance) return error('Invalid amount');
    if (!/^([13]|bc1)[a-zA-Z0-9]{25,40}$/.test(recipient)) return error('Invalid address');

    status.className = 'status status--info';
    status.textContent = 'Broadcasting...';
    status.style.display = 'inline-flex';

    await this.delay(800);

    this.transactions.unshift({ id: this.randomHex(64), amount: -amount, conf: 0, time: Date.now() });
    this.updateBalanceDisplay();
    this.renderTxHistory();

    status.className = 'status status--success';
    status.textContent = 'Sent!';
    setTimeout(() => this.hideSendModal(), 900);
  }

  /* ---------------- Utilities ---------------- */
  randomHex(len) {
    const arr = new Uint8Array(len/2);
    crypto.getRandomValues(arr);
    return [...arr].map(b => b.toString(16).padStart(2,'0')).join('');
  }

  delay(ms) {
    return new Promise(res => setTimeout(res, ms));
  }

  logout() {
    localStorage.removeItem('satsdash_session');
    this.currentUser = null;
    this.walletData = null;
    this.transactions = [];
    this.balance = 0;
    this.showLanding();
  }
}

// Instantiate after DOM ready
window.addEventListener('DOMContentLoaded', () => {
  window.satsDash = new BitcoinWalletDemo();
});